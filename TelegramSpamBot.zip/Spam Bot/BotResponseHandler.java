package com.example.telegrambot;

public class BotResponseHandler {

    public static String generateResponse(String userMessage) {
        switch (userMessage.toLowerCase()) {
            case "/start":
                return "Hello! I'm your friendly Telegram bot. Type /help to see what I can do.";
            case "/help":
                return "Available commands:\n/start - Start the bot\n/help - Get help\n/echo - Repeat your message\n/joke - Tell a random joke";
            case "/joke":
                return "Here's a joke for you: Why don’t skeletons fight each other? They don’t have the guts!";
            default:
                return "You said: " + userMessage + ". Type /help for commands!";
        }
    }
}
